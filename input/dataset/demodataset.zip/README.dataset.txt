# Vechile segmentation South h3 > 2023-11-20 1:05pm
https://universe.roboflow.com/rptu-av2mn/vechile-segmentation-south-h3

Provided by a Roboflow user
License: CC BY 4.0

